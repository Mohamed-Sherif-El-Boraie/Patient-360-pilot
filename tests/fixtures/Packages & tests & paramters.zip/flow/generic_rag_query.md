Reusable clinical retrieval instruction
Identify laboratory tests that may be clinically useful as additional investigations, confirmatory tests, or follow-up tests based on the provided patient's entire current test profile and historical results. Consider abnormal high and low values, trends, critical flags, patient demographics, existing tests and clinical relationships. Search the available test catalog and identify relevant complementary tests, avoiding unnecessary repetitions. Return only candidates supported by the catalog descriptions. Do not treat retrieved matches as definitive medical recommendations.


RETRIEVAL_INSTRUCTION = """
Search the laboratory test catalog for clinically relevant
additional, complementary, confirmatory, or follow-up tests
based on this patient's entire current and historical
laboratory profile.

Consider:
- All existing tests and individual parameters.
- High, low, abnormal, and critical findings.
- Reference ranges, units, and laboratory flags.
- Historical results and changes over time.
- Patient age and sex.
- Relationships between laboratory findings.
- Tests that can help clarify unexplained abnormalities.
- Avoid unnecessary duplication of existing tests.
- Return only candidates supported by the catalog descriptions. 
- Do not treat retrieved matches as definitive medical recommendations.
Retrieve candidate tests from the available catalog.




import json

RETRIEVAL_INSTRUCTION = """
Search the laboratory test catalog for clinically relevant
additional, complementary, confirmatory, or follow-up tests
based on this patient's entire current and historical
laboratory profile.

Consider:
- All existing tests and individual parameters.
- High, low, abnormal, and critical findings.
- Reference ranges, units, and laboratory flags.
- Historical results and changes over time.
- Patient age and sex.
- Relationships between laboratory findings.
- Tests that can help clarify unexplained abnormalities.
- Avoid unnecessary duplication of existing tests.
- Return only candidates supported by the catalog descriptions.
- Do not treat retrieved matches as definitive medical recommendations.
Retrieve candidate tests from the available catalog.
"""

def build_retrieval_query(patient_payload):
    return (
        RETRIEVAL_INSTRUCTION
        + "\n\nPATIENT DATA:\n"
        + json.dumps(
            patient_payload,
            ensure_ascii=False
        )
    )

# JSON 1: RetrieveAndGenerate
one_call_request["input"]["text"] = (
    build_retrieval_query(patient_payload)
    + "\n\nAnalyze the complete patient data and "
      "retrieved test catalog. Produce the patient "
      "report in the required JSON structure."
)

# JSON 2: Retrieve
retrieve_request["retrievalQuery"]["text"] = (
    build_retrieval_query(patient_payload)
)

# JSON 3: InvokeModel after retrieval
invoke_request["messages"][0]["content"][0]["text"] = (
    json.dumps(
        {
            "patient_payload": patient_payload,
            "retrieved_tests": retrieved_tests
        },
        ensure_ascii=False
    )
)







# Guardrail - JSON 3 InvokeModel + Guardrail for urgent/on-demand/symptom


import boto3
import json

bedrock_runtime = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION
)

response = bedrock_runtime.invoke_model(
    modelId=MODEL_ID,
    contentType="application/json",
    accept="application/json",

    # Guardrail configuration
    guardrailIdentifier=GUARDRAIL_ID,
    guardrailVersion=GUARDRAIL_VERSION,

    # Your complete JSON 3
    body=json.dumps(model_request, ensure_ascii=False)
)
