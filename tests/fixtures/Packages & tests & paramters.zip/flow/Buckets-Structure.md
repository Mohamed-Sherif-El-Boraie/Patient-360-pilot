# **Azure Blob 1 Input Folder (Json Files)**

```
/raw
        --/on-demand        files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/urgent           files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/batch            files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/symptom-checker  files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/_rejected        files: {source}/{yyyy}/{MM}/{dd}/{visit_id}.json

/processed
        --/on-demand
        ----/normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        ----/critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/urgent
        ----/normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        ----/critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/batch
        ----/normal         files: {yyyy}/{MM}/{dd}/{batch_id}/{idempotency_key}.json
        ----/normal-jsonls  files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
        ----/critical       files: {yyyy}/{MM}/{dd}/{batch_id}/{idempotency_key}.json
        ----/critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
        --/symptom-checker
        ----/normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        ----/critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
```



# **S3 Bucket 1 — On-Demand**

```
/processed
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-rag-retrieval-results
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-input-english
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-english-generation-guardrail
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-input-arabic
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-arabic
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-merged
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
```

# **S3 Bucket 2 — Urgent**

```
/processed
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-rag-retrieval-results
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-input-english
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-english-generation-guardrail
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-input-arabic
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-arabic
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-merged
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
```


# **S3 Bucket 3 — Symptom Checker**

```
/processed
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-rag-retrieval-results
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-input-english
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-english-generation-guardrail
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-input-arabic
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-arabic
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json

/aws-output-merged
    /normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
    /critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
```


# **S3 Bucket 4 — Batch**

```
/processed
    /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
    /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl

/aws-output-rag-retrieval-results
    /normal          files: {yyyy}/{MM}/{dd}/{batch_id}/{idempotency_key}.jsonl
    /critical        files: {yyyy}/{MM}/{dd}/{batch_id}/{idempotency_key}.jsonl

/aws-input-english
    /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
    /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl

/aws-output-english-generation-guardrail
    /inference-output
        /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
        /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
    /guardrail-output
        /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
        /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl

/aws-input-arabic
    /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
    /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl

/aws-output-arabic
    /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
    /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl

/aws-output-merged
    /normal-jsonls   files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
    /critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
```


# **Azure Blob 2 Output Folder (Json Files)**

```
/aws-output-merged
        --/on-demand
        ----/normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        ----/critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/urgent
        ----/normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        ----/critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        --/batch
        ----/normal         files: {yyyy}/{MM}/{dd}/{batch_id}/{idempotency_key}.json
        ----/normal-jsonls  files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
        ----/critical       files: {yyyy}/{MM}/{dd}/{batch_id}/{idempotency_key}.json
        ----/critical-jsonls files: {yyyy}/{MM}/{dd}/{batch_id}.jsonl
        --/symptom-checker
        ----/normal         files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
        ----/critical       files: {yyyy}/{MM}/{dd}/{idempotency_key}.json
```

## 1. Knowledge Base architecture

### 🗄️ Standard S3 bucket — source data

* `knowledge-base/laboratory_tests.csv`
* `knowledge-base/laboratory_tests.csv.metadata.json`

⬇️

### Amazon Bedrock Knowledge Base

CSV parsing → row-level content → embedding model → vector indexing

⬇️

### 🗄️⚡ S3 Vectors bucket

Vector index containing embedded catalogue tests and associated metadata

⬇️

### Bedrock `Retrieve` API

Queries the indexed catalogue and returns up to 10 relevant chunks

## 2. AWS metadata configuration

Upload two files to your Knowledge Base S3 source.

File 1: `laboratory_tests.csv`

```TypeScript
test_name,test
Hemoglobin A1c (HbA1c),"Hemoglobin A1c (HbA1c): Measures average blood glucose over approximately 2–3 months."
Serum Ferritin,"Serum Ferritin: Measures stored iron and supports investigation of iron deficiency or overload."
TSH,"TSH: Measures thyroid-stimulating hormone and helps assess thyroid function."
```

File 2: `laboratory_tests.csv.metadata.json`

```Shell

{
  "documentStructureConfiguration": {
    "type": "RECORD_BASED_STRUCTURE_METADATA",
    "recordBasedStructureMetadata": {
      "contentFields": [
        {
          "fieldName": "test"
        }
      ],
      "metadataFieldsSpecification": {
        "fieldsToInclude": [
          {
            "fieldName": "test_name"
          }
        ]
      }
    }
  }
}
```

![1792623476452](image/Buckets-Structure/1792623476452.png)

```TypeScript
RETRIEVAL_INSTRUCTION = """
Search the laboratory test catalog for clinically relevant
additional, complementary, confirmatory, or follow-up tests
based on this patient's entire current and historical
laboratory profile.

Consider:

- All existing tests and individual parameters.
- High, low, abnormal, and critical findings.
- Reference ranges, units, and laboratory flags.
- Historical results and changes over time.
- Patient age and sex.
- Relationships between laboratory findings.
- Tests that can help clarify unexplained abnormalities.
- Avoid unnecessary duplication of existing tests.
- Return only candidates supported by the catalog descriptions.
- Do not treat retrieved matches as definitive medical recommendations.
  Retrieve candidate tests from the available catalog.
  """
```

```TypeScript
def build_retrieval_query(patient_payload):
    return (
        RETRIEVAL_INSTRUCTION
        + "\n\nPATIENT DATA:\n"
        + json.dumps(
            patient_payload,
            ensure_ascii=False
        )
    )

response = bedrock_agent_runtime.retrieve(
    knowledgeBaseId=KNOWLEDGE_BASE_ID,
    retrievalQuery={"text": query},
    retrievalConfiguration={
        "vectorSearchConfiguration": {
            "numberOfResults": 10
        }
    }
)
```

```json
{
  "retrievalResults": [
    {
      "content": {
        "type": "TEXT",
        "text": "Hemoglobin A1c (HbA1c): Measures average blood glucose over the previous two to three months."
      },
      "metadata": {
        "test_name": "Hemoglobin A1c (HbA1c)"
      },
      "location": {
        "type": "S3",
        "s3Location": {
          "uri": "s3://YOUR-BUCKET/catalog/laboratory_tests.csv"
        }
      },
      "score": 0.89
    },
    {
      "content": {
        "type": "TEXT",
        "text": "Serum Ferritin: Measures stored iron and supports investigation of iron deficiency or overload."
      },
      "metadata": {
        "test_name": "Serum Ferritin"
      },
      "location": {
        "type": "S3",
        "s3Location": {
          "uri": "s3://YOUR-BUCKET/catalog/laboratory_tests.csv"
        }
      },
      "score": 0.81
    }
  ]
}
```

**Retrieved Tests should be added to Patient Data**

```Python
{
  "retrieved_tests": [
    {
      "test": "Hemoglobin A1c (HbA1c): Measures average blood glucose over approximately 2–3 months."
    }
  ]
}
```

# 4. AWS functions needed

For the implementation, I would organize it into the following functions:

| Function                   | AWS service              | Responsibility                                    |
| -------------------------- | ------------------------ | ------------------------------------------------- |
| `start_batch_workflow`   | Step Functions           | Start and track batch execution                   |
| `retrieve_patient_tests` | Lambda + Bedrock KB      | Retrieve up to 10 catalogue chunks per patient   |
| `prepare_batch_jsonl`    | Lambda + S3              | Serialize enriched records into valid batch input |
| `submit_batch_job`       | Lambda + Bedrock         | Create inference job with token                   |
| `check_batch_status`     | Step Functions / Bedrock | Wait for job completion and handle failures       |
| `apply_output_guardrail` | Lambda + Bedrock Runtime | Check each generated report                       |
| `finalize_results`       | Lambda + S3              | Consolidate final JSONL and processing statuses   |

# A. Ingestion

```Python
import boto3bedrock_agent = boto3.client("bedrock-agent")def start_catalogue_ingestion(
    knowledge_base_id,
    data_source_id
):
    response = bedrock_agent.start_ingestion_job(
        knowledgeBaseId=knowledge_base_id,
        dataSourceId=data_source_id
    )
    return response["ingestionJob"]["ingestionJobId"]def check_catalogue_ingestion(
    knowledge_base_id,
    data_source_id,
    ingestion_job_id
):
    response = bedrock_agent.get_ingestion_job(
        knowledgeBaseId=knowledge_base_id,
        dataSourceId=data_source_id,
        ingestionJobId=ingestion_job_id
    )
    return response["ingestionJob"]["status"]
```

## Lambda 1 — `retrieve_patient_tests`

```Python

def retrieve_patient_tests(event, context):
    record_id = event["recordId"]
    patient = event["patient_payload"]

    query = (
        RETRIEVAL_INSTRUCTION
        + "\n\nPATIENT DATA:\n"
        + json.dumps(patient, ensure_ascii=False)
    )

    # Bedrock retrieval text has a length limit.
    if len(query) > 20000:
        raise ValueError(
            "Retrieval query too long: "
            "apply a clinically safe summarization policy"
        )

    response = kb_runtime.retrieve(
        knowledgeBaseId=KB_ID,
        retrievalQuery={"text": query},
        retrievalConfiguration={
            "vectorSearchConfiguration": {
                "numberOfResults": 30
            }
        }
    )

    tests = []
    seen = set()

    for item in response.get("retrievalResults", []):
        metadata = item.get("metadata", {})
        name = metadata.get("test_name")
        content = item.get("content", {})

        if not name or content.get("type") != "TEXT":
            continue

        if name in seen:
            continue

        seen.add(name)
        tests.append({
            "test_name": name,
            "test": content.get("text", "")
        })

    return {
        "recordId": record_id,
        "patient_payload": patient,
        "retrieved_tests": tests,
        "retrieval_status": "completed",
        "retrieved_count": len(tests)
    }
```

## Lambda 2 — `prepare_batch_jsonl`

## Lambda 3 — `submit_batch_job`

## Lambda 4 — `apply_output_guardrail`

## Lambda 5 — `finalize_results`
